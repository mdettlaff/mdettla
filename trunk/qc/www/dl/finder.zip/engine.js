//sprawdza czy zosta�o podane has�o do wyszukania
function check(ok)
{
if (ok == 'nie')
{
if (document.find.what.value != "")
	{
	znajdz();
	} else {
	error('Nie podano wyszukiwanego has�a.');
	}
}
}

//G��wna funkcja engine'u AMSE
wynik = new Array();

function znajdz()//bylo (tryb)
{
y=1;
haslo_orginal = document.find.what.value;
haslo = haslo_orginal.toLowerCase();
//rozdzielaenia na autora i 
for (x = 1; x <= (dane.length-1); x ++)
	{
	if ((document.find.opc_1.checked == true)&&(document.find.opc_2.checked == false))
	   {
	   //wyszukiwanie wg autorow artow
	   if (dane[x].autor.toLowerCase().indexOf(haslo) != -1)
	   	  {
		  wynik[y] = x;
		  y++;
		  }	   
	   }
	if ((document.find.opc_1.checked == false)&&(document.find.opc_2.checked == true))
	   {
	   //wyszukiwanie wg tytulow artow
	   if (dane[x].tytul.toLowerCase().indexOf(haslo) != -1)
	   	  {
		  wynik[y] = x;
		  y++;
		  }
	   }
	if ((document.find.opc_1.checked == true)&&(document.find.opc_2.checked == true))
	   {
	   //wyszukiwanie wg tytulow artow i autorow
	   text = dane[x].autor;
	   text = text.toLowerCase(); 
	   text2 = dane[x].tytul;
	   text2 = text2.toLowerCase();
	   if ((text.indexOf(haslo) != -1) || (text2.indexOf(haslo) != -1))
	   	  {
		  wynik[y] = x;
		  y++;
		  }
	   }
	}
draw_results(wynik);
}


//wyswietla strone zawierajaca wyniki wyszukiwania
bgcol = new Array();
bgcol[1] = "ADD8E6";
bgcol[3] = "#8ba8e2";
swcol = 1;

function draw_results(tablica)
{
document.clear();
//poczatek
header = '<html><head><title>Queen Corner - wyniki wyszukiwania</title></head>';
header +='<BODY bgcolor=#b2c5ec link=black alink=red vlink=black text=black>';
header +='<CENTER>&nbsp;..:: Wyniki wyszukiwania ::..&nbsp;<BR>';
header +='<hr noshade color="white" size="1"><BR>';
header +='<table width=543 border=0 cellpadding=3 align=center>';
document.write(header);

for (x = 1; x <= (tablica.length-1); x++)
	{
	swcol = swcol * -1;
	bgc = bgcol[2+swcol];
	document.write('<tr><td style="background-color: ' + bgc + '"><a id=search href="' + dane[tablica[x]].sciezka + '"> ' + dane[tablica[x]].tytul + '</a></td><td style="background-color: ' + bgc + '"><b>' + dane[tablica[x]].autor + '</b></td></tr>');
	}
if (tablica.length == 0)
   {
   document.write('Nie znaleziono �adnych piosenek ani album�w odpowiadaj�cych kryteriom wyszukiwania.');
   }
//zakonczenie
ending = '</table>';
document.write(ending);
}
function error(opis)
{
alert('-- Queen Corner Searching Engine --\n               by Glorfindel\n\n            B��D\n\n' + opis);
}


