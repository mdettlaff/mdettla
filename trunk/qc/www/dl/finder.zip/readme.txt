                          Song Finder Info:

Glorfindel(mike_b@poczta.fm) - skrypt wyszukiwarki
Mi� Eryk(miseryk@poczta.onet.pl) - modyfikacje skryptu, design, dane.js
Mumin - baza tekst�w, pomys� projektu
Queen - tw�rcy i wykonawcy wszystkich zamieszczonych tu piosenek. 

                           Song Finder
                              dla
                         Queen's Corner 
                         
                         September 2002