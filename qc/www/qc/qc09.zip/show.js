
adres=adresstr

document.writeln("<html><head></head><body bgcolor=white leftmargin=30 topmargin=30 bottommargin=0>")

document.write("<iframe frameborder=0 style='position:absolute;top:10;left:10' height=")
document.write(screen.height-140," width=",screen.width-164," src=",adres,"><br></iframe>")

document.writeln("<img src='pixczarny.jpg' style='position:absolute; width:2; height:800;  left:4; top:5'>")
document.writeln("<img src='pixczarny.jpg' style='position:absolute; width:1400; height:2;  left:5; top:4'>")
document.writeln("<img src='pixczarny.jpg' style='position:absolute; width:1400; height:2;  left:5; bottom:4'>")
document.writeln("<img src='pixbialy.jpg' style='position:absolute; width:2; height:6;  left:4; bottom:-1'>")

document.writeln("<img src='pixczarny.jpg' style='position:absolute; width:1; height:1;  left:0; top:0'>")
document.writeln("<img src='pixczarny.jpg' style='position:absolute; width:1; height:1;  left:0; bottom:0'>")
document.writeln("</body></html>")