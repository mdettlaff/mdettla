package mdettla.jade.hello;

import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.OneShotBehaviour;

public class MyAgent extends Agent {
	private static final long serialVersionUID = 1L;

	protected void setup() {
		System.out.println("Moj agent: setup");

		Behaviour behaviour = new OneShotBehaviour(this) {
			private static final long serialVersionUID = 1L;

			public void action() {
				System.out.println("Nazywam sie " + getAID().getName());
				System.out.println("Jestem wolny w poniedzialek!");
			}
		};
		addBehaviour(behaviour);
	}
}
